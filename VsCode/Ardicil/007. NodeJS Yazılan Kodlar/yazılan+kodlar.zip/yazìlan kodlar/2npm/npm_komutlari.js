//npm init -> npm kullanmamız için package.json yapısını oluşturur. --yes ile tüm sorulara default cevaplar verilir.
//npm i veya install -g npm@6.14.4 --> global olarak npmyi ilgili sürüm olarka yükler


//Semantic Versiyon Nedir
//"mongoose" : "^4.13.6" // Major.Minor.Patch
//Patch sayısı hata düzeltmelerinde arttırılır.
//Minor yeni bir özellik eklenmiştir ve var olan yapıyı bozmayacak bir değişiklikse arttırılır.
//Major var olan yapıyı bozan bir güncelleme geldiyse bu arttırılır.
//^ dediğimizde tüm minor ve patch güncellemeleri almak istediğimizi söylemiş oluruz.
//~ dediğimizde sadece patchleri almış oluruz.

//odev
//var olan tüm paketleri <nodemon dahil> siliniz.
// yargs 15.3.1 chalk 4.0.0 versiyonuyla modulleri kurunuz. Fikir edinmek için dökümantasyonlarına bakınız
//app.js dosyası olusturup nodemon ile başlatınız

console.log("merhaba emre deneme");
