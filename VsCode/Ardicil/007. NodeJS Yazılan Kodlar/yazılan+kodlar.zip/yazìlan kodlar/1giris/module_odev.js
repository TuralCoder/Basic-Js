//bilgisayar pc_info bir modul oluşturun
//bu modülün amacı nodejs uygulamasının çalıştığı makinayla ilgili verileri göstermek olacak.
//os hazır modulünü kullanarak bu işlemi gerçekleştirebilirsiniz.
//bu modülü kullanarak bilgisayarın toplam kaç gb ram, kullanılan ve free ram miktarları ile kaç cpu oldugunu yazan bir fonksiyon
//olusturup, son sonucu  pc_info.txt dosyasına yazdıran bir program yazınız.
//bu program başka dosyalardan da çağrılabilmelidir.

